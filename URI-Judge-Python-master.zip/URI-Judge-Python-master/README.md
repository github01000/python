# URI Judge: Python
[URI Judge](https://www.urionlinejudge.com.br) - Exercícios resolvidos em Python
